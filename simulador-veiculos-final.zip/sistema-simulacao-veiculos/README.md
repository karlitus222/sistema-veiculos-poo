# Sistema de Simulação de Veículos

Projeto em Java desenvolvido para a disciplina de Programação Orientada a Objetos.

## Estrutura do projeto

- `Veiculo`: classe base com atributos encapsulados, métodos de ação, consumo, abastecimento e identidade por placa.
- `Carro`: herda de `Veiculo`, possui sobrecarga de construtores, sobrescrita de `acelerar`, `exibirStatus` e `toString`.
- `Moto`: herda de `Veiculo`, acelera mais rápido e possui atributo `cilindradas`.
- `Caminhao`: herda de `Veiculo`, possui maior consumo e capacidade de carga.
- `Garagem`: gerencia um array fixo de veículos e usa sobrecarga de `estacionar`.
- `SimuladorDeTrafego`: substitui a garagem simples por uma pista de testes com interação entre veículos.
- `Main`: executa a demonstração completa das três partes da atividade.

## Requisitos atendidos

- Herança
- Encapsulamento
- Sobrecarga de construtores
- Sobrecarga de métodos
- Sobrescrita de métodos
- `toString`
- `equals` e `hashCode`
- Tratamento simples de erros com `if/else`
- Uso de arrays de tamanho fixo

## Como executar

### Compilar
```bash
javac src/*.java
```

### Executar
```bash
java -cp src Main
```

## Sugestão para o GitHub

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta.
3. Copie o link do repositório e envie na atividade.
