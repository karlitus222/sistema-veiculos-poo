/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class Moto extends Veiculo {
    private int cilindradas;

    public Moto(String marca, String modelo, String placa, int cilindradas) {
        super(marca, modelo, placa);
        this.cilindradas = cilindradas;
    }

    public Moto(String marca, String modelo, String placa, double velocidadeInicial, int cilindradas) {
        super(marca, modelo, placa, velocidadeInicial, 0.0);
        this.cilindradas = cilindradas;
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    @Override
    public void acelerar() {
        acelerar(15);
    }

    @Override
    public double calcularConsumo() {
        return 0.07;
    }

    @Override
    public String exibirStatus() {
        return super.exibirStatus() + ", Cilindradas: " + cilindradas + " cc";
    }
}
