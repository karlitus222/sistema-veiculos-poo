/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class Main {
    public static void main(String[] args) {
        System.out.println("=== ATIVIDADE 4 - SISTEMA DE SIMULAÇÃO DE VEÍCULOS ===\n");

        Carro carro1 = new Carro("Toyota", "Corolla", "ABC-1234");
        Carro carro2 = new Carro("Honda", "Civic", "DEF-5678", 20);
        Moto moto1 = new Moto("Yamaha", "Fazer 250", "GHI-9012", 250);
        Caminhao caminhao1 = new Caminhao("Volvo", "FH", "JKL-3456", 18.0);

        System.out.println("--- PARTE 1: TESTES COM CARRO ---");
        carro1.abastecer(20);
        carro1.ligar();
        carro1.acelerar();
        carro1.acelerar(12);
        carro1.frear();
        System.out.println(carro1);

        System.out.println("\n--- PARTE 2: GARAGEM COM FROTA DIVERSIFICADA ---");
        Garagem garagem = new Garagem(3);
        garagem.estacionar(carro1);
        garagem.estacionar(moto1);
        garagem.estacionar(caminhao1);
        garagem.estacionar(carro2);
        garagem.listarVeiculos();

        moto1.abastecer(12, "Gasolina");
        moto1.ligar("Esportivo");
        moto1.acelerar();
        System.out.println(moto1.exibirStatus());

        System.out.println("\n--- PARTE 3: SIMULADOR DE TRÁFEGO ---");
        SimuladorDeTrafego simulador = new SimuladorDeTrafego(5);
        simulador.adicionarVeiculo(carro1);
        simulador.adicionarVeiculo(moto1);
        simulador.adicionarVeiculo(caminhao1);

        caminhao1.abastecer(60, "Diesel");
        caminhao1.ligar("Carga");
        caminhao1.acelerar(8);

        simulador.interagir(carro1, moto1);
        simulador.interagir(caminhao1, carro1);
        simulador.exibirPista();

        System.out.println("\n--- TESTE DE EQUALS / HASHCODE ---");
        Carro carroDuplicado = new Carro("Toyota", "Corolla Altis", "ABC-1234");
        System.out.println("carro1 é igual ao carroDuplicado? " + carro1.equals(carroDuplicado));

        System.out.println("\n--- TESTE DE ROBUSTEZ ---");
        Carro semCombustivel = new Carro("Fiat", "Mobi", "MNO-7890");
        semCombustivel.ligar();
        semCombustivel.acelerar();
    }
}
