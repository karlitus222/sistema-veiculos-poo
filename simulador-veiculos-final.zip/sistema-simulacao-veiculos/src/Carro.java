/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class Carro extends Veiculo {
    private int numeroPortas;

    public Carro(String marca, String modelo, String placa) {
        this(marca, modelo, placa, 0.0, 4);
    }

    public Carro(String marca, String modelo, String placa, double velocidadeInicial) {
        this(marca, modelo, placa, velocidadeInicial, 4);
    }

    public Carro(String marca, String modelo, String placa, double velocidadeInicial, int numeroPortas) {
        super(marca, modelo, placa, velocidadeInicial, 0.0);
        this.numeroPortas = numeroPortas;
    }

    public int getNumeroPortas() {
        return numeroPortas;
    }

    public void setNumeroPortas(int numeroPortas) {
        this.numeroPortas = numeroPortas;
    }

    @Override
    public void acelerar() {
        acelerar(10);
    }

    @Override
    public String exibirStatus() {
        return super.exibirStatus() + ", Número de portas: " + numeroPortas;
    }

    @Override
    public String toString() {
        return "Carro: [" + getMarca() + "] [" + getModelo() + "] - Velocidade: ["
                + String.format("%.1f", getVelocidade()) + "] km/h";
    }
}
