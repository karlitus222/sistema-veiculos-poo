/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class SimuladorDeTrafego {
    private Veiculo[] pista;
    private int quantidade;

    public SimuladorDeTrafego(int capacidade) {
        this.pista = new Veiculo[capacidade];
        this.quantidade = 0;
    }

    public boolean adicionarVeiculo(Veiculo veiculo) {
        if (veiculo == null) {
            System.out.println("Erro: veículo inválido.");
            return false;
        }

        if (quantidade >= pista.length) {
            System.out.println("Erro: pista cheia. O simulador não pode receber mais veículos.");
            return false;
        }

        pista[quantidade] = veiculo;
        quantidade++;
        System.out.println(veiculo.getModelo() + " entrou na pista.");
        return true;
    }

    public void interagir(Veiculo a, Veiculo b) {
        if (a == null || b == null) {
            System.out.println("Erro: interação inválida.");
            return;
        }
        a.interagir(b);
    }

    public void interagir(Caminhao caminhao, Veiculo outro) {
        if (caminhao == null || outro == null) {
            System.out.println("Erro: interação inválida.");
            return;
        }
        System.out.println("O caminhão " + caminhao.getModelo() + " exige maior distância ao interagir com " + outro.getModelo() + ".");
    }

    public void exibirPista() {
        System.out.println("\n=== VEÍCULOS NA PISTA ===");
        if (quantidade == 0) {
            System.out.println("Pista vazia.");
            return;
        }

        for (int i = 0; i < quantidade; i++) {
            System.out.println((i + 1) + ". " + pista[i].exibirStatus());
        }
    }
}
