/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class Garagem {
    private Veiculo[] veiculos;
    private int quantidade;

    public Garagem(int capacidade) {
        this.veiculos = new Veiculo[capacidade];
        this.quantidade = 0;
    }

    public boolean estacionar(Carro c) {
        return estacionarVeiculo(c);
    }

    public boolean estacionar(Moto m) {
        return estacionarVeiculo(m);
    }

    public boolean estacionar(Caminhao c) {
        return estacionarVeiculo(c);
    }

    public boolean estacionar(Veiculo v) {
        return estacionarVeiculo(v);
    }

    private boolean estacionarVeiculo(Veiculo veiculo) {
        if (veiculo == null) {
            System.out.println("Erro: veículo inválido.");
            return false;
        }

        if (quantidade >= veiculos.length) {
            System.out.println("Erro: garagem cheia. Não foi possível estacionar " + veiculo.getModelo() + ".");
            return false;
        }

        veiculos[quantidade] = veiculo;
        quantidade++;
        System.out.println(veiculo.getClass().getSimpleName() + " estacionado com sucesso.");
        return true;
    }

    public void listarVeiculos() {
        System.out.println("\n=== VEÍCULOS NA GARAGEM ===");
        if (quantidade == 0) {
            System.out.println("Garagem vazia.");
            return;
        }

        for (int i = 0; i < quantidade; i++) {
            System.out.println((i + 1) + ". " + veiculos[i]);
        }
    }

    public Veiculo getVeiculo(int indice) {
        if (indice < 0 || indice >= quantidade) {
            return null;
        }
        return veiculos[indice];
    }

    public int getQuantidade() {
        return quantidade;
    }
}
