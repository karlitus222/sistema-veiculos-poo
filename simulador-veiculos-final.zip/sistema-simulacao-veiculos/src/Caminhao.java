/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

public class Caminhao extends Veiculo {
    private double capacidadeCarga;

    public Caminhao(String marca, String modelo, String placa, double capacidadeCarga) {
        super(marca, modelo, placa);
        this.capacidadeCarga = capacidadeCarga;
    }

    public Caminhao(String marca, String modelo, String placa, double velocidadeInicial, double capacidadeCarga) {
        super(marca, modelo, placa, velocidadeInicial, 0.0);
        this.capacidadeCarga = capacidadeCarga;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public void setCapacidadeCarga(double capacidadeCarga) {
        this.capacidadeCarga = capacidadeCarga;
    }

    @Override
    public double calcularConsumo() {
        return 0.20;
    }

    @Override
    public String exibirStatus() {
        return super.exibirStatus() + ", Capacidade de carga: " + String.format("%.1f", capacidadeCarga) + " t";
    }
}
