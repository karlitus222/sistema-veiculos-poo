/*
 * Autor: Carlos Gabriel Raposo Landim
 * Curso: Engenharia de Software
 * Período: 3º período
 */

import java.util.Objects;

public class Veiculo {
    private String marca;
    private String modelo;
    private double velocidade;
    private String placa;
    private double combustivel;
    private boolean ligado;

    public Veiculo(String marca, String modelo, String placa) {
        this(marca, modelo, placa, 0.0, 0.0);
    }

    public Veiculo(String marca, String modelo, String placa, double velocidade, double combustivel) {
        this.marca = marca;
        this.modelo = modelo;
        this.placa = placa;
        this.velocidade = Math.max(0, velocidade);
        this.combustivel = Math.max(0, combustivel);
        this.ligado = false;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getVelocidade() {
        return velocidade;
    }

    protected void setVelocidade(double velocidade) {
        this.velocidade = Math.max(0, velocidade);
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getCombustivel() {
        return combustivel;
    }

    protected void setCombustivel(double combustivel) {
        this.combustivel = Math.max(0, combustivel);
    }

    public boolean isLigado() {
        return ligado;
    }

    protected void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    public void ligar() {
        ligado = true;
        System.out.println(getClass().getSimpleName() + " ligado.");
    }

    public void ligar(String modo) {
        ligado = true;
        System.out.println(getClass().getSimpleName() + " ligado no modo " + modo + ".");
    }

    public void acelerar() {
        acelerar(5);
    }

    public void acelerar(double incremento) {
        if (!ligado) {
            System.out.println("Erro: o veículo precisa estar ligado para acelerar.");
            return;
        }

        double consumoNecessario = calcularConsumo() * incremento;
        if (combustivel < consumoNecessario) {
            System.out.println("Erro: combustível insuficiente para acelerar.");
            return;
        }

        velocidade += incremento;
        combustivel -= consumoNecessario;
        System.out.println(getClass().getSimpleName() + " acelerou para " + String.format("%.1f", velocidade) + " km/h.");
    }

    public void frear() {
        frear(5);
    }

    public void frear(double decremento) {
        velocidade -= decremento;
        if (velocidade < 0) {
            velocidade = 0;
        }
        System.out.println(getClass().getSimpleName() + " reduziu para " + String.format("%.1f", velocidade) + " km/h.");
    }

    public void abastecer(double litros) {
        if (litros <= 0) {
            System.out.println("Erro: informe uma quantidade válida para abastecer.");
            return;
        }
        combustivel += litros;
        System.out.println("Abastecimento comum realizado: +" + String.format("%.1f", litros) + " L.");
    }

    public void abastecer(double litros, String tipoCombustivel) {
        if (litros <= 0) {
            System.out.println("Erro: informe uma quantidade válida para abastecer.");
            return;
        }
        combustivel += litros;
        System.out.println("Abastecimento com " + tipoCombustivel + ": +" + String.format("%.1f", litros) + " L.");
    }

    public double calcularConsumo() {
        return 0.10;
    }

    public void interagir(Veiculo outro) {
        if (outro == null) {
            System.out.println("Nenhum veículo disponível para interação.");
            return;
        }
        System.out.println(this.modelo + " está trafegando ao lado de " + outro.getModelo() + ".");
    }

    public String exibirStatus() {
        return "Marca: " + marca
                + ", Modelo: " + modelo
                + ", Placa: " + placa
                + ", Velocidade: " + String.format("%.1f", velocidade) + " km/h"
                + ", Combustível: " + String.format("%.1f", combustivel) + " L"
                + ", Ligado: " + (ligado ? "Sim" : "Não");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Veiculo veiculo)) return false;
        return Objects.equals(placa, veiculo.placa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(placa);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + ": [" + marca + "] [" + modelo + "] - Velocidade: ["
                + String.format("%.1f", velocidade) + "] km/h";
    }
}
