# Simulador de Veículos (Java)

Projeto desenvolvido para a disciplina de Programação Orientada a Objetos.

## 👨‍💻 Autor
Carlos Gabriel Raposo Landim  
3º período - Engenharia de Software  

## 📌 Sobre o projeto
Esse sistema simula diferentes tipos de veículos (carro, moto e caminhão), utilizando conceitos de orientação a objetos em Java.

Também possui uma garagem para armazenar os veículos e uma simulação simples de funcionamento.

## 🚀 Funcionalidades
- Cadastro de veículos
- Aceleração dos veículos
- Exibição das informações
- Armazenamento em garagem
- Simulação básica de tráfego

## 🧠 Conceitos utilizados
- Herança
- Encapsulamento
- Sobrescrita de métodos (override)
- Sobrecarga de métodos (overload)
- Uso de arrays
- Organização em classes

## ▶️ Como executar
1. Abra o projeto em uma IDE
2. Compile os arquivos
3. Execute a classe Main.java

## 📚 Observação
Projeto desenvolvido com fins acadêmicos.
